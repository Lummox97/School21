/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/05 14:35:46 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/05 15:09:45 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_strlcat(char *dest, char *src, unsigned int size)
{
	int i;

	i = 0;
	if (size < 1)
		return (0);
	while (*dest != '\0')
	{
		i++;
		dest++;
	}
	while (i < size - 1 && *src != '\0')
	{
		i++;
		*dest = *src;
		dest++;
		src++;
	}
	*dest = '\0';
	return (i);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/04 15:46:04 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/06 01:35:39 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	int i;
	int flag;

	flag = 0;
	i = 0;
	while (i <= n)
	{
		if (src[i] == '\0')
			flag = 1;
		if (flag == 1)
			dest[i] = '\0';
		else
			dest[i] = src[i];
		i++;
	}
	return (dest);
}

int main(void)
{
	char str1[] = "qwertyui", str2[] = "zxcvbnm";
	str1 = ft_strncpy(str1, str2);
}

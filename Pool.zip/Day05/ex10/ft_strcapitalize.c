/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/04 20:34:46 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/06 20:06:27 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str)
{
	int i;

	i = 0;
	if (str[0] >= 'a' && str[0] <= 'z')
	{
		str[0] += 'A' - 'a';
		i++;
	}
	while (str[i] != '\0')
	{
		if ((str[i] < '0' || str[i] > 'z' || (str[i] > '9' && str[i] < 'A') ||
					(str[i] > 'Z' && str[i] < 'a'))
				&& str[i + 1] >= 'a' && str[i + 1] <= 'z')
		{
			i++;
			str[i] += 'A' - 'a';
			i++;
		}
		if (str[i] >= 'A' && str[i] <= 'Z')
			str[i] += 'a' - 'A';
		i++;
	}
	return (str);
}
#include <stdio.h>
int main(void)
{
	char s[] = "sk ej hbfk";
	ft_strcapitalize(s);
	printf("%s", s);
}

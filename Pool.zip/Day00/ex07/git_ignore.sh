git check-ignore .* *

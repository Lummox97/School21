git log -5 --pretty=format:%H

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   testtest.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/16 16:35:29 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/17 20:32:37 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int		ft_strcmp(char *s1, char *s2);
char	*rush00(int x, int y);

int		ru0(int *x, int *y)
{
	char	str[2048];
	int		i;
	int		fd;
	int		flag;

	i = 0;
	flag = 0;
	while (i < 2048)
		str[i++] = 0 ;
	str[0] = 'o';
	while((fd = read(0, &str[i], 1)))
	{
		y++;
		if (flag == 0)
			x++;
		if (str[i] == '\n')
			flag = 1;
		i++;
	}
	printf("\nПРОЧИТАННЫЙ : %s", str);
	return (ft_strcmp(str, rush00(*x, *y)));
}

char	*rush00(int x, int y)
{
	int		i;
	int		j;
	char	*str;

	i = 1;
	str = malloc(x * y + 1);
	while (i <= y)
	{
		j = 1;
		while (j++ <= x)
			if (i == 1)
				if ((j - 1 == 1) || (j - 1 == x))
					str[j * x + i] = 'o';
				else
					str[j * x + i] = '-';
			else if (i == y)
				if ((j - 1 == x) || (j - 1 == 1))
					str[j * x + i] = 'o';
				else
					str[j * x + i] = '-';
			else if ((j - 1 == x) || (j - 1 == 1))
				str[j * x + i] = '|';
			else
				str[j * x + i] = ' ';
		str[j * x + i] = '\n';
		i++;
	}
	str[x * y] = '\0';
	printf("\nЛЕГИТИМНЫЙ : %s", str);
}


int		main(void)
{
	char	c[5];
	int		x;
	int		y;
	int		fd;
	int		flag;

	x = 1;
	y = 1;
	flag = 1;
	fd = read(0, &c[0], 1);
	if (fd != 0)
	{
//		if (c[0] == '/')
//			flag = ru1(&x, &y);
		if (c[0] == 'o')
			flag = ru0(&x, &y);
//		if (c[0] == 'A')
//			flag = ru234();
//		if (flag == 0)
//			printf("aucune");
	}
	printf("shire:%i\nvys:%i\n", x, y / x);
	if (c[1] == 'A')
	{
		if (c[2] == 'A')
			printf("[rush-02]");
		else
		{
			if (c[2] == 'C' && c[4] == 'C')
				printf("[rush-03]");
			else if (c[2] == 'C' && c[4] == 'A')
				printf("[rush-04]");
			else
				printf("aucune");
		}
	}
	if (c[1] == '/')
		printf("[rush-01]");
	if (flag == 0)
		printf("[rush-00]");

	//printf("%c", c);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/02/28 23:12:37 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/02 15:42:10 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_atoi(char *str)
{
	int flag;
	int number;

	flag = 1;
	number = 0;
	while ((*str == ' ') || (*str == '\t') || (*str == '\n')
			|| (*str == '\v') || (*str == '\f') || (*str == '\r'))
		str++;
	if (*str == '-')
	{
		flag = -1;
		str++;
	}
	if (*str == '+')
	{
		str++;
	}
	while ((*str > '0') && (*str < '9'))
	{
		number = number * 10 + (*str) - 48;
		str++;
	}
	return (number * flag);
}
#include <stdio.h>
int main(void)
{
	printf("%i", ft_atoi("   -+34jk4"));
			}

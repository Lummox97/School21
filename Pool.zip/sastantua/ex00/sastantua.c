/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sastantua.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/03 00:10:35 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/04 17:54:03 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

int		last_str_lenghth(int depth, int size, int sch, int plus)
{
	if (size == 0)
		return (0);
	if (depth == size)
		return (sch);
	if (depth == 1)
		plus = 10;
	else
		plus += 2;
	if (depth % 2 == 1)
		plus += 2;
	return (last_str_lenghth(depth + 1, size, sch + plus, plus));
}

int		print_door(int k, int *stars, int size, int str)
{
	if ((k > (*stars) / 2 - (size + 1) / 2 + 1)
			&& (k <= (*stars) / 2 + (size + 1) / 2) && (((str > 2)
					&& (size % 2 == 1)) || ((str > 3) && (size % 2 == 0))))
	{
		if ((size > 4) && (k == (*stars) / 2 + (size - 1) / 2)
				&& (((size % 2 == 0) && (str == 3 + (size + 1) / 2))
					|| ((size % 2 == 1) && (str == 2 + (size + 1) / 2))))
			ft_putchar('$');
		else
			ft_putchar('|');
		return (1);
	}
	return (0);
}

void	print_str(int len_and_size[2], int *stars, int block, int str)
{
	int k;
	int size;

	size = len_and_size[1];
	k = 0;
	while (k++ < len_and_size[0])
		ft_putchar(' ');
	ft_putchar('/');
	k = 0;
	while (k++ < *stars)
		if ((block == 1) && print_door(k, stars, size, str))
			continue;
		else
			ft_putchar('*');
	ft_putchar(92);
	ft_putchar('\n');
	(*stars) += 2;
}

void	sastantua(int size)
{
	int i;
	int j;
	int len_and_size[2];
	int minus;
	int stars;

	len_and_size[1] = size;
	i = 0;
	minus = 2;
	stars = 1;
	len_and_size[0] = (last_str_lenghth(1, size, 5, 0) - 1) / 2;
	while (i < size)
	{
		j = 0;
		while (j++ < i + 3)
		{
			print_str(len_and_size, &stars, size - i, j);
			len_and_size[0]--;
		}
		i++;
		if ((i % 2 == 1) && (i != 1))
			minus++;
		len_and_size[0] -= minus;
		stars += 2 * minus;
	}
}

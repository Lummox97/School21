/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_at.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/13 18:36:29 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/13 23:12:55 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list	*ft_list_at(t_list *begin_list, unsigned int nbr)
{
	unsigned int i;

	i = 0;
	while (i < nbr && begin_list->next != 0)
	{
		if (begin_list == 0)
			return (0);
		i++;
		begin_list = begin_list->next;
	}
	if (i == nbr)
		return (begin_list);
	return (0);
}

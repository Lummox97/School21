/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_reverse.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/13 18:45:10 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/13 23:39:00 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void	ft_list_reverse(t_list **begin_list)
{
	t_list *prev;
	t_list *next;
	t_list *copy;

	copy = *begin_list;
	if (!copy || !copy->next)
		return ;
	prev = copy;
	copy = copy->next;
	while (copy->next)
	{
		next = copy->next;
		copy->next = prev;
		prev = copy;
		copy = next;
	}
	*begin_list = copy;
}

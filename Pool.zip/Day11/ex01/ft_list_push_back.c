/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_back.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/13 15:06:52 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/13 22:33:58 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

void	ft_list_push_back(t_list **begin_list, void *data)
{
	t_list	*cur_elem;
	t_list	*new;

	cur_elem = *begin_list;
	new = ft_create_elem(data);
	if (cur_elem)
	{
		while (cur_elem->next)
			cur_elem = cur_elem->next;
		cur_elem->next = new;
	}
}

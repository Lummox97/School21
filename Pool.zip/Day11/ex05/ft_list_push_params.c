/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_list_push_params.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/13 15:54:02 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/13 23:04:27 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_list.h"

t_list	*ft_list_push_params(int ac, char **av)
{
	t_list	*new;
	t_list	*prev;
	int		i;

	prev = ft_create_elem(av[0]);
	new = 0;
	i = ac - 1;
	if (prev)
	{
		while (i > 0)
		{
			new = ft_create_elem(av[i]);
			new->next = prev;
			prev = new;
			i--;
		}
	}
	new = prev;
	return (new);
}

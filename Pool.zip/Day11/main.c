/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/13 14:41:52 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/13 23:25:48 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "./ex00/ft_list.h"
#include <stdio.h>

void	ft_list_push_back(t_list **begin_list, void *data);
void    ft_list_push_front(t_list **begin_list, void *data); 
int		ft_list_size(t_list *begin_list);
t_list	*ft_list_last(t_list *begin_list);
t_list	*ft_list_push_params(int ac, char **argv);
t_list	*ft_list_at(t_list *begin_list, unsigned int nbr);
void	ft_list_reverse(t_list **a);

int main(int argc, char **argv)
{
	t_list	*a, b, c, d, *tet;
	char str[] = "abc";

	a = ft_create_elem("aaa");
	b.data = "bbb";
	c.data = "ccc";
	d.data = "ddd";
	a->next = &b;
	b.next = &c;
	c.next = &d;
	d.next = 0;
	ft_list_push_back(&a, str);
	ft_list_push_front(&a, "123");
	tet = a;
	while (tet)
	{
		printf("%s\n", tet->data);
		tet = tet->next;
	}
	printf("%i\n", ft_list_size(a));
	printf("%s\n\n", ft_list_last(a)->data);
	tet = a; 
	while (tet != 0) 
	{
		printf("%s\n", tet->data); 
		tet = tet->next;
	}
	tet = ft_list_push_params(argc, argv);
	while (tet != 0)
	{
		printf("%s\n", tet->data);
		tet = tet->next;
	}
	tet = ft_list_at(a, 3);
	printf("\n%s\n", tet->data);
	ft_list_reverse(&a);
	while (a != 0)
	{
		printf("%s\n", a->data);
		a = a->next;
	}
}

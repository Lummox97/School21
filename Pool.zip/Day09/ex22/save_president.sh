mkdir bunker
cd bunker/


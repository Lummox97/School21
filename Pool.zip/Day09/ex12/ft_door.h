/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_door.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 04:44:55 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 05:01:20 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef __FT_DOOR_H
# define __FT_DOOR_H
# define OPEN TRUE
# define CLOSE FALSE

typedef bool	ft_bool

typedef struct	s_door
{
	ft_bool state;
}				t_door;
#endif

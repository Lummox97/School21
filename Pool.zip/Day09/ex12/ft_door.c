/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_door.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 04:20:42 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 05:17:49 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_door.h"

void	ft_putstr(char *str)
{
	int	i = 0;

	while (*str)
		write(1, str++ ,1);
}

ft_bool	close_door(t_door *door)
{
	ft_putstr("Door closing...");
	state = CLOSE;
	return (TRUE);
}

void	is_door_open(t_door door)
{
	ft_putstr("Door is open ?");
	return (door->state = OPEN);
}

ft_bool	is_dooe_close(t_door *door)
{
	ft_putstr("Door is close ?");
}

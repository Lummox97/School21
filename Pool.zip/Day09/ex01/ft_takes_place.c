/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_takes_place.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/07 17:42:12 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/07 18:03:50 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_takes_place(int hour)
{
	int vrem;

	if (hour < 0 || hour > 24)
		return ;
	if (hour == 24)
	{
		printf("THE FOLLOWING TAKES PLACE BETWEEN");
		printf(" 0.00 A.M. AND 1.00 A.M.\n");
	}
	else
	{
		if (hour >= 12)
		{
			printf("THE FOLLOWING TAKES PLACE BETWEEN");
			printf(" %i.00 P.M. AND %i.00 P.M.\n", hour - 12, hour - 11);
		}
		else
		{
			printf("THE FOLLOWING TAKES PLACE BETWEEN");
			printf(" %i.00 A.M. AND %i.00 A.M.\n", hour, hour + 1);
		}
	}
}

#!/bin/sh
if !(ifconfig | grep "inet " | cut -f 2 -d " "); then echo "I am lost!\n";
fi

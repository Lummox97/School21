stat -f %a bomb.txt | xargs echo "-1 + " | bc

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_perso.h                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 03:58:30 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 05:01:25 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef __FT_PERSO_H
# define __FT_PERSO_H

# include <string.h>
# define SAVE_THE_WORLD

typedef struct	s_perso
{
	int		age;
	float	life;
	char	*name;
	char	*profession;
}				t_perso;
#endif

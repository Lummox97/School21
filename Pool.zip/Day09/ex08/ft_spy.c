/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_spy.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 00:36:36 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 01:20:13 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	strdown(int a, char **strs)
{
	int i;
	int j;

	i = 1;
	j = 0;
	while (i < a)
	{
		while (strs[i][j] != '\0')
		{
			if (strs[i][j] >= 'A' && strs[i][j] <= 'Z')
				strs[i][j] += 'a' - 'A';
			j++;
		}
		i++;
	}
}

int		ft_strcmp(char *str1, char *str2)
{
	int i;

	i = 0;
	while (*str1 == ' ' || *str1 == '\n' || *str1 == '\t')
		str1++;
	while (str2[i] != '\0')
	{
		if (str1[i] != str2[i] || (str1[i] - str2[i] == 'A' - 'a'))
			return(0);
		i++;
	}
	return (1);
}

int		main(int argc, char **argv)
{
	int i;

	i = 1;
	strdown(argc, argv);
	while (i < argc)
	{
		if (ft_strcmp(argv[i], "president") || ft_strcmp(argv[i], "attack")
				|| ft_strcmp(argv[i], "bauer"))
			write(1, "Alert!!!\n", 10);
		i++;
	}
}

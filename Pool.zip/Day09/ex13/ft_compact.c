/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_compact.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 05:22:44 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 06:00:35 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_compact(char **tab, int length)
{
	int		i;
	int		j;
	int		cp;

	i = 0;
	cp = 0;
	while (i < length)
	{
		j = i;
		if (tab[i] == 0)
		{
			while (j < length - 1)
			{
				tab[j] = tab[j + 1];
				j++;
			}
		}
		i++;
	}
	while (tab[cp] != 0)
		cp++;
	return (cp);
}

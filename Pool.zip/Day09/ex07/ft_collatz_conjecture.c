/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_collatz_conjecture.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/07 23:48:24 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 00:17:04 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

unsigned int	ft_collatz_conjecture(unsigned int base)
{
	int res;

	if (base == 1)
		return (0);
	if (base % 2 == 1)
		res = 1 + ft_collatz_conjecture(base * 3 + 1);
	if (base % 2 == 0)
		res = 1 + ft_collatz_conjecture(base / 2);
	return (res);
}

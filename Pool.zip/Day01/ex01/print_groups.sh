#!/bin/bash
groups $FT_USER | tr " " ","

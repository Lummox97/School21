/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fcodi.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcodi <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/09 17:46:31 by fcodi             #+#    #+#             */
/*   Updated: 2019/03/10 17:09:38 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void	put_char(char c)
{
	write(1, &c, 1);
}

int		put_digit(int i)
{
	if (i <= 9 && i >= 0)
		put_char((char)(i + '0'));
	else
		return (-1);
	return (0);
}

int		string_length(char *str)
{
	int		i;

	i = -1;
	while (str[++i] != '\0')
		continue;
	return (i);
}

void	put_massive(int *m, int size)
{
	int		i;

	i = -1;
	while (++i < size)
	{
		put_digit(m[i]);
		put_char(' ');
	}
	put_char('\n');
}

void	put_matrix(int **m, int size, char **argv)
{
	int		i;

	i = -1;
	while (++i < size - 1)
		put_massive(m[i], string_length(argv[i + 1]));
}

int		*malloc_massive(char *str)
{
	return ((int*)malloc(sizeof(int) * string_length(str)));
}

int		**malloc_matrix(int args, char **argv)
{
	int		i;
	int		**m;

	m = (int**)malloc(sizeof(int**) * args - 1);
	i = -1;
	while (++i < args)
		m[i] = malloc_massive(argv[i]);
	return (m);
}

int		**get_matrix(int args, char **argv)
{
	int		**m;
	int		i;
	int		j;

	i = 0;
	m = malloc_matrix(args, argv);
	while (++i < args)
	{
		j = -1;
		while (argv[i][++j] != '\0')
		{
			if (argv[i][j] == '.')
				m[i - 1][j] = 0;
			else
				m[i - 1][j] = argv[i][j] - '0';
			printf("i = %d, j = %d, m[i - 1][j] = %d, argv[i][j] = %c\n",
					i, j, m[i - 1][j], argv[i][j]);
		}
	}
	return (m);
}

int		match_line(int *m, int size, int start, int digit)
{
	int		i;

	i = start - 1;
	printf("start = %d, size = %d, digit = %d\n", start, size, digit);
	while (++i < (start + size))
	{
		printf("i = %d, m[i] = %d\n", i, m[i]);
		if (m[i] == digit)
			return (((i + 1) * 10) + digit);
	}
	return (0);
}

int		match_column(int **m, int column, int size, int start, int digit)
{
	int		i;

	i = start - 1;
	printf("start = %d, size = %d, column = %d, digit = %d\n", start, size,
			column, digit);
	while (++i < (start + size))
	{
		printf("i = %d, m[i][column] = %d\n", i, m[i][column]);
		if (m[i][column] == digit)
			return ((i + 1) + ((column + 1) * 10));
	}
	return (0);
}

int		match_square_lines(int **m, int size, int start, int digit)
{
	int		i;
	int		line;

	i = start - 1;
	while (++i < (start + size))
	{
		line = match_line(m[i], size, start, digit);
		if (line != 0)
			return (((i + 1) * 100) + ((i + 1) * 10) + digit);
	}
	return (0);
}

int		match_square_columns(int **m, int size, int start, int digit)
{
	int		i;
	int		column;

	i = start - 1;
	while (++i < (start + size))
	{
		column = match_column(m, i, size, start, digit);
		if (column != 0)
			return (((i + 1) * 100) + ((column + 1) * 10) + digit);
	}
	return (0);
}

int		match_square(int **m, int square_number, int digit)
{
	const int	size = 3;
	const int	l[] = {-1, 0, 4, 7, 0, 4, 7, 0, 4, 7};
	const int	c[] = {-1, 0, 0, 0, 4, 4, 4, 7, 7, 7};
	int			lines;
	int			columns;

	lines = match_square_lines(m, size, l[square_number], digit);
	if (lines != 0)
		return ((square_number * 1000) + lines);
	columns = match_square_columns(m, size, c[square_number], digit);
	if (columns != 0)
		return ((square_number * 1000) + columns);
	return (0);
}

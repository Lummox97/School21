/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Dtilda.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/09 19:31:36 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/10 22:13:09 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		**glav_recurs(int **sud, int **moz, int pos)
{
	if (pos != 80)
		if (sud[(pos + 1) / 9][(pos + 1) % 9] == 0 || moz[pos / 9][pos % 9] == 1)
			sud = glav_recurs(sud, moz, pos + 1);
	while (sud[pos / 9][sud % 9] <= 9)
	{
		sud[pos / 9][pos % 9]++;
		if (mozno_li(sud, pos))
			return (sud);
		else if (pos == 80)
			КАКТО ПРОПИСАТЬ ВЫХОД ИЗ ВСЕХ УРОВНЕЙ
		else
			glav_recurs(sud, moz, pos + 1);
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fcodi <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/09 17:48:30 by fcodi             #+#    #+#             */
/*   Updated: 2019/03/10 02:58:22 by fcodi            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int		**get_matrix(int args, char **argv);
int		**put_matrix(int **m, int size, char **argv);
int		match_square(int **m, int square_number, int digit);
int		match_line(int *m, int size, int start, int digit);
int		match_column(int **m, int column, int size, int start, int digit);

int		main(int args, char **argv)
{
	int		**m;
	int		result;

	m = get_matrix(args, argv);
	put_matrix(m, args, argv);
	result = match_line(m[4], 9, 2, 5);
	printf("=============== result = %d\n", result);
	result = match_column(m, 7, 9, 0, 8);
	printf("=============== result = %d\n", result);
	result = match_square(m, 5, 5);
	printf("=============== result = %d\n", result);
	return (0);
}

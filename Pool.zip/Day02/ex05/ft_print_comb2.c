/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/02/27 19:50:46 by dtilda            #+#    #+#             */
/*   Updated: 2019/02/28 21:15:51 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

void	ft_print_comb2(void)
{
	int big_number;

	big_number = 0;
	while (big_number < 9900)
	{
		if (big_number / 100 > big_number % 100)
			big_number += big_number / 100 + 1;
		ft_putchar((big_number / 1000 + '0'));
		ft_putchar((big_number / 100 - big_number / 1000 * 10 + '0'));
		ft_putchar(' ');
		ft_putchar((big_number / 10 - (big_number / 100) * 10 + '0'));
		ft_putchar((big_number % 10 + '0'));
		if (big_number != 9899)
			ft_putchar(',');
		if (big_number != 9899)
			ft_putchar(' ');
		big_number++;
	}
}

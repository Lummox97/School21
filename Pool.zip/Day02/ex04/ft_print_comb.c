/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/02/27 17:32:07 by dtilda            #+#    #+#             */
/*   Updated: 2019/02/28 21:15:05 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_putchar(char c);

void	ft_print_comb(void)
{
	char i;
	char j;
	char k;

	i = '0';
	while (i < '8')
	{
		j = i++;
		while (j < '9')
		{
			k = j++;
			while (k < ':')
			{
				ft_putchar(i - 1);
				ft_putchar(j - 1);
				ft_putchar(k);
				if ((i != '8') || (j != '9') || (k != '9'))
					ft_putchar(',');
				if ((i != '8') || (j != '9') || (k != '9'))
					ft_putchar(' ');
				k++;
			}
		}
	}
}

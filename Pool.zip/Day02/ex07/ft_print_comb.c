/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/02/28 16:46:57 by dtilda            #+#    #+#             */
/*   Updated: 2019/02/28 21:43:33 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print_combn(int n)
{
	int i;
	int j;
	int max_number
	
	i = 0;
	while (i < 10 ^ n)
	{

		i++;
}

int		main(void)
{
	ft_print_combn(3);
	ft_putchar('\n');
	ft_print_combn(2);
	return (0);
}

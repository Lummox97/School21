/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_insert_data.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/15 21:32:21 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/15 23:06:21 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

void	btree_insert_data(t_btree **root, void *item,
		int (*cmpf)(void *, void *))
{
	t_btree *tmp;

	if (*root == 0)
	{
		*root = btree_create_node(item);
		return ;
	}
	tmp = *root;
	if (cmpf(item, tmp->item) < 0)
		btree_insert_data(&(tmp->left), item, cmpf);
	else
		btree_insert_data(&(tmp->right), item, cmpf);
}

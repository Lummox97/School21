/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   btree_level_count.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/15 23:25:51 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/16 17:20:17 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_btree.h"

int		btree_level_count(t_btree *root)
{
	int a;
	int b;
	
	if (root == 0)
	return (0);
	a = btree_level_count(root->left);
	b = btree_level_count(root->right);
	if (a > b)
		return (1 + a);
	else
		return (1 + b);
}

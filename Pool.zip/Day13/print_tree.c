/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print_tree.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/15 04:18:04 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/15 23:08:59 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ex01/ft_btree.h"
#include <stdio.h>

void    btree_apply_prefix(t_btree *root, void (*applyf)(void *));
void    tr_print(void *item);
void    btree_apply_infix(t_btree *root, void (*applyf)(void *));
void    btree_apply_suffix(t_btree *root, void (*applyf)(void *));
void    btree_insert_data(t_btree **root, void *item, int (*cmpf)(void *, void *));

int		count_tree(t_btree *root)
{
	if (root == 0)
		return (0);
	return (1 + count_tree(root->left) + count_tree(root->right));
}

void    tr_print(void *item)
{
	printf("%s", item);
}

void	count_print_tree(t_btree *root)
{
	int left, right;
	t_btree *copy;

	left = 0;
	right = 0;
	copy = root;
	while (copy != 0)
	{
		copy = copy->left;
		left++;
	}
	while (copy != 0)
	{
		copy = copy->right;
		right++;
	}
//	print_tree(left, right, root);
}

int		char_cmp(void *s1, void *s2)
{
	return((char*)s1 -(char *)s2);
}
/*
void	print_tree(int left, int right, t_btree *root)
{
	int i;

	i = 0;
	while (i < left)
	{
		printf(" ");
		i++;
	}
	printf("%s", root->item);
	
}	*/

int		main(void)
{
	t_btree *a, b, c, d, e;

	a = 0;
//	a = btree_create_node("a");
//	a->left = &b;
//	a->right = &c;

	b.item = "b";
	b.left = &d;
	b.right = 0;

	c.item = "c";
	c.right = &e;
	c.left = 0;
	
	d.item = "d";
	d.left = 0;
	d.right = 0;
	
	e.item = "e";
	e.left = 0;
	e.right = 0;
	
	btree_insert_data(&a, "d", &char_cmp);
	printf("%i", count_tree(a));
	btree_apply_prefix(a, tr_print);
	printf("\n");
	btree_apply_infix(a, tr_print);
	printf("\n");
	btree_apply_suffix(a, tr_print);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/17 20:47:43 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/17 23:05:08 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/head.h"

int		aatoi(char **str)
{
	int		res;

	res = 0;
	while (**str == ' ')
		(*str)++;
	if (**str == '(')
	{
		(*str)++;
		res = vtor_prior(str);
	}
	if (**str == ')')
	{
		(*str)++;
		return (res);
	}
	while (**str >= '0' && **str <= '9')
	{
		res = res * 10 + **str - '0';
		(*str)++;
	}
	return (res);
}

int		per_prior(char **str)
{
	int		res;

	res = aatoi(str);
	while (1)
	{
		while (**str == ' ')
			(*str)++;
		if (**str != '*' && **str != '/' && **str != '%')
			return (res);
		if (**str == '*')
		{
			(*str)++;
			res *= aatoi(str);
		}
		if (**str == '/')
		{
			(*str)++;
			res /= aatoi(str);
		}
		if (**str == '%')
		{
			(*str)++;
			res = res % aatoi(str);
		}
	}
}

int		vtor_prior(char **str)
{
	int		res;

	res = per_prior(str);
	while (1)
	{
		while (**str == ' ')
			(*str)++;
		if (**str != '+' && **str != '-')
			return (res);
		if (**str == '+')
		{
			(*str)++;
			res += per_prior(str);
		}
		if (**str == '-')
		{
			(*str)++;
			res -= per_prior(str);
		}
	}
}

int		eval_expr(char *str)
{
	return (vtor_prior(&str));
}

int		main(int ac, char **av)
{
	if (ac > 1)
	{
		ft_putnbr(eval_expr(av[1]));
		ft_putchar('\n');
	}
	return (0);
}

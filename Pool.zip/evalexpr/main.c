/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/16 04:13:38 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/17 08:31:55 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include "../includes/head.h"

int		prior(char a, char b)
{
	if (a == '+' || a == '-')
		a = 2;
	if (a == '*' || a == '/' || a == '%')
		a = 4;
	if (b == '+' || b == '-' || b == '\0')
		b = 1;
	if (b == '*' || b == '/' || b == '%')
		b = 2;
	return (a - b);
}

int		oper(int a, int b, char o)
{
	if (o == '+')
		return (a + b);
	if (o == '-')
		return (a - b); 
	if (o == '*')
		return (a * b); 
	if (o == '/')
		return (a / b); 
	if (o == '%')
		return (a % b);
	return (a);
}	

int		eval_expr(char *str)
{
	int		a[2048];
	int		i;
	char	b[1024];
	char	*copy;
	int		j;

	i = 0;
	while (i < 1024)
	{
		a[i] = 0;
		b[i] = 0;
		i++;
	}
	copy = str;
	i = 0;
	a[0] = ft_atoi(&str);
	printf("\n CЧИТАЛ %i", a[i]);
	str++;
	b[0] = *str;
	printf("\n CЧИТАЛ %c", b[i]);
	i++;
	str++;
	while (*str)
	{
		a[i] = ft_atoi(&str);
		printf("\n CЧИТАЛ %i", a[i]);
		str++;
		b[i] = *str;
		printf("\n СЧИТАЛ %c", b[i]);
		if (prior(b[i - 1], b[i]))
		{
			printf("\nПРИОРИТЕТНОСТЬ ХОРОШАЯ %c %c, СЧИТАЮ %i, %i\n ", b[i - 1], b[i], a[i - 1], a[i]);
			a[i - 1] = oper(a[i - 1], a[i], b[i - 1]);
			b[i - 1] = b[i];
			a[i] = 0;
			b[i] = 0;
			i--;
		}
		i++;
		str++;
	}
	j = 0;
	while (b[j] != 0)
	{
		printf("%i  %c  ", a[j], b[j]);
		j++;
	}
	printf("%i", a[j]);
	j = 0;
	while (b[j] != 0)
	{
		printf("\nСЧИТАЮ %i %c %i", a[0], b[j], a[j+1]);
		a[0] = oper(a[0], a[j + 1], b[j]);
		b[j] = 0;
		a[j + 1] = 0;
		j++;
	}
	printf("\n");
	j = 0;
	while (j < 3)
		printf("%i\n", a[j++]);
	j = -1;
	return (a[0]);
}
/*
int		evalexp2(char *str)
{
	int		res;
	int		i;
	int		a[1024];
	char	b[1024];

	i = 0;
	while(i < 1024)
	{
		a[i] = 0;
		b[i] = 0;
	}
	while (*str)
	{
		while (*str == ' ')
			str++;
//		if (*str == '(')
//			res = evalexp2(str);
		if (*str >= '0' && *str <= '9')
			a[i] = ft_atoi(&str);
		if (*str == '+' || *str == '-' || *str == '/' || *str == '*'
				|| *str == '%')
		{
			b[i] = *str;
			str++;
			i++;
		}
//		if (*str == ')')
//			return(count(a, b, i));
	}

}*/

int		main(int argc, char ** argv)
{
	printf("%i", eval_expr("-6 + 43 / 3 + 4 * 6 * 8 % 3 + 5"));
}

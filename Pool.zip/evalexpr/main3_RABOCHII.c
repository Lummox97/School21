/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/17 20:47:43 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/17 22:42:08 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/head.h"
#include <stdio.h>

int		aatoi(char **str)
{
	int		res;
	int		flag;

	res = 0;
	flag = 1;
	while(**str == ' ')
		(*str)++;
	if (**str == '(')
	{
		(*str)++;
		res = vtor_prior(str);
	}
	if (**str == ')')
	{
		(*str)++;
		return (res);
	}
	if (**str == '-')
	{
		flag = -1;
		(*str)++;
	}
	while(**str >= '0' && **str <= '9')
	{
		res = res * 10 + **str - '0';
		(*str)++;
	}
	printf ("\nСЧИТАЛ %i", res);
	return (res * flag);
}

int		per_prior(char **str)
{
	int		res;

	res = aatoi(str);
	printf("\nРЕЗУЛЬТАТ ИЗ ПЕРВОГО ПРИОРИТЕТА 1 : %i, CТРОКА НА %c", res, **str);
	while (1)
	{
		while (**str == ' ')
			(*str)++;
		if (**str != '*' && **str != '/' && **str != '%')
		{
			printf("ВЫХОДИМ ИЗ ПЕРВОГОб СТРОКА НА %c", **str);
			return (res);
		}
//		(*str)++;
		if (**str == '*')
		{
			(*str)++;
			res *= aatoi(str);
		}
		if (**str == '/')
		{
			(*str)++;
			res /= aatoi(str);
		}
		if (**str == '%')
		{
			(*str)++;
			res = res % aatoi(str);
		}
		printf("\nРЕЗУЛЬТАТ ИЗ ПЕРВОГО ПРИОРИТЕТА 2 : %i, CТРОКА НА %c", res, **str);
//		(*str)++;
	}
}

int		vtor_prior(char **str)
{
	int		res;

	printf("\n           НАЧАЛО");
	res = per_prior(str);
	printf("\nРЕЗУЛЬТАТ ИЗ ВТОРОГО ПРИОРИТЕТА 1 : %i, CТРОКА НА %c", res, **str);
	while (1)
	{
		while (**str == ' ')
			(*str)++;
		if (**str != '+' && **str != '-')
		{
			printf("ВЫХОДИМ ИЗ ВТОРОГО, СТРОКА НА %c", **str);
			return (res);
		}
		if (**str == '+')
		{
			(*str)++;
			res += per_prior(str);
		}
		if (**str == '-')
		{
			(*str)++;
			res -= per_prior(str);
		}
		printf("\nРЕЗУЛЬТАТ ИЗ ВТОРОГО ПРИОРИТЕТА 2 : %i, CТРОКА НА %c", res, **str);
//		(*str)++;
	}
}

int		eval_expr(char *str)
{
	return (vtor_prior(&str));
}

int		main(int argc, char **argv)
{
	printf("\n%i", eval_expr(argv[1]));
}

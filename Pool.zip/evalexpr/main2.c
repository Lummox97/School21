/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/17 08:36:49 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/17 20:44:01 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdio.h>
#include "../includes/head.h"

int		prior(char a, char b)
{
	if (a == '+' || a == '-')
		a = 2;
	if (a == '*' || a == '/' || a == '%')
		a = 3;
	if (b == '+' || b == '-' || b == '\0' || b == ')' || b == 's')
		b = 1;
	if (b == '*' || b == '/' || b == '%')
		b = 2;
	if (b == '(')
		b = 5;
	return (a - b);
}

int		oper(int a, int b, char o)
{
	if (o == '+')
		return (a + b);
	if (o == '-')
		return (a - b);
	if (o == '*')
		return (a * b);
	if (o == '/')
		return (a / b);
	if (o == '%')
		return (a % b);
	return (a);
}

int		calc(int *a, char *b, int i, int j)
{
	while (b[j] != 0)
	{
		printf("%i  %c  ", a[j], b[j]);
		j++;
	}
	printf("%i", a[j]);
	j = 0;
	i = 0;
	while (b[j] != 0 && b[j] != ')')
	{
		if (prior(b[j], b[j + 1]) > 0)
		{
			a[i + 1] = oper(a[i], a[i + 1], b[j]);
			a[i] = 0;
			b[j] = 's';
		}
		j++;
		i++;
	}
	printf("\n");
	j = 0;
	while (b[j] != 0)
	{
		printf("%i  %c  ", a[j], b[j]);
		j++;
	}
	printf("%i", a[j]);
}

int		schet()

int		eval_expr(char *str)
{
	int		a[1024];
	char	b[1024];
	int		i;
	int		j;

	i = 0;
	while (i < 1024)
	{
		a[i] = 0;
		b[i] = 0;
		i++;
	}
	i = 0;
	j = 0;
	while (*str)
	{
		if (*str == '(')
			b[j++] = *str;
		if ((*str >= '0' && *str <= '9') || *str == '-')
			a[i++] = ft_atoi(&str);
		if (*str == '+' || *str == '-' || *str == '*' || *str == '/' ||
				*str == '%')
			b[j++] = *str;
		str++;
	}
	calc(a, b, 0, 0);
	return (0);
}

int		main(void)
{
	printf("%i", eval_expr("7 + 4 * 8 * 3 + 2"));
	}	

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 13:35:13 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/12 23:33:58 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int		main(int argc, char **argv)
{
	int		first;
	int		second;
	t_opp	arg;
	int		res;

	g_isnul = 0;
	if (argc != 4)
		return (0);
	first = ft_atoi(argv[1]);
	second = ft_atoi(argv[3]);
	if (second == 0)
		g_isnul = 1;
	arg = is_arg_valid(argv[2]);
	if (arg.f == 0)
	{
		write(1, "0", 1);
		return (0);
	}
	res = calc(first, second, arg.f);
	return (res);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   functions.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 14:05:27 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/13 10:49:19 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"
#include "ft_opp.h"

t_opp	is_arg_valid(char *s)
{
	int		i;

	i = 0;
	while (ft_strcmp(g_opptab[i].str, "") != 0)
	{
		if (ft_strcmp(g_opptab[i].str, s) == 0)
			return (g_opptab[i]);
		i++;
	}
	return (g_opptab[i]);
}

int		calc(int a, int b, int (*f) (int, int))
{
	int res;

	res = f(a, b);
	if (g_isnul != 5)
	{
		ft_putnbr(res);
		write(1, "\n", 1);
	}
	return (0);
}

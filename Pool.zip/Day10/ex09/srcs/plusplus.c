/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   plusplus.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 17:21:23 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/12 23:38:41 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int		ft_add(int a, int b)
{
	return (a + b);
}

int		ft_sub(int a, int b)
{
	return (a - b);
}

int		ft_mul(int a, int b)
{
	return (a * b);
}

int		ft_div(int a, int b)
{
	if (g_isnul == 1)
	{
		write(1, "Stop : divizion by zero\n", 25);
		g_isnul = 5;
		return (0);
	}
	return (a / b);
}

int		ft_mod(int a, int b)
{
	if (g_isnul == 1)
	{
		write(1, "Stop : module by zero\n", 22);
		g_isnul = 5;
		return (0);
	}
	return (a % b);
}

int		ft_usage(int a, int b)
{
	write(1, "error : only [ + - * / % ] are accepted.\n", 41);
	g_isnul = 5;
	return (a + b);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 17:33:28 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/12 23:38:29 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef __HEADER_H
# define __HEADER_H
# include <unistd.h>

int				g_isnul;

typedef struct	s_opp
{
	char	*str;
	int		(*f) (int, int);
}				t_opp;

t_opp			is_arg_valid(char *s);
int				ft_add(int a, int b);
int				ft_sub(int a, int b);
int				ft_mul(int a, int b);
int				ft_div(int a, int b);
int				ft_mod(int a, int b);
int				ft_usage(int a, int b);
int				calc(int a, int b, int (*f) (int, int));
int				ft_atoi(char *str);
void			ft_putnbr(int nb);
void			ft_putchar(char c);
int				ft_strcmp(char *s1, char *s2);
#endif

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/11 20:29:06 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/13 01:42:19 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void    ft_foreach(int *tab, int length, void(*f)(int));
int		*ft_map(int *tab, int len, int(*f)(int));
int		ft_any(char **tab, int(*f)(char*));
int		ft_count_if(char **tab, int(*f)(char*));
int		ft_is_sort(int *tab, int length, int(*f)(int, int));

int		is_s(char *str)
{
	while (*str != '\0')
	{
		if (*str == 'o')
			return (1);
		str++;
	}
	return (0);
}

int		changenbr(int a)
{
	return (a + 5);
}

void	print_num(int a)
{
	printf("%i ", a);
}

int		cmp(int a, int b)
{
	if (a == b)
		return (0);
	if (a < b)
		return (-1);
	return (1);
}

int main(void)
{
	int a[11] = {-332773, -319072, -177960, -174019, -97770, -58101, -26947, -19342, 61793, 295351, 297030};
	char s1[] = "aosdf", s2[] = "fokgs", *s[3];
	s[0] = s1;
	s[1] = s2;
	s[2] = 0;
//	printf("%i\n", ft_count_if(s, is_s));
//	a = ft_map(a, 5, changenbr);
	printf("%i\n", ft_is_sort(a, 11, cmp));
	ft_foreach(a, 5, print_num);
}

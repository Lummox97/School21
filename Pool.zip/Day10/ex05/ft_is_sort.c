/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_sort.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 12:50:45 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/12 19:07:26 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_is_sort(int *tab, int length, int (*f) (int, int))
{
	int i;
	int vec;

	i = 0;
	if (length < 0)
		return (0);
	if (length <= 2)
		return (1);
	while (f(tab[i], tab[i + 1]) == 0 && i < length - 1)
		i++;
	if (i == length - 1)
		return (1);
	else
		vec = f(tab[i], tab[i + 1]);
	while (i < length - 1)
	{
		if (f(tab[i], tab[i + 1]) != vec && f(tab[i], tab[i + 1]) != 0)
			return (0);
		i++;
	}
	return (1);
}

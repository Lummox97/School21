/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   plusplus.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 17:21:23 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/12 17:50:21 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		pluss(int a, int b)
{
	return (a + b);
}

int		minuss(int a, int b)
{
	return (a - b);
}

int		multipll(int a, int b)
{
	return (a * b);
}

int		dividd(int a, int b)
{
	return (a / b);
}

int		modd(int a, int b)
{
	return (a % b);
}

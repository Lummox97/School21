/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   functions.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 14:05:27 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/12 20:32:01 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int		is_arg_valid(char *s)
{
	int i;

	i = 0;
	while (s[i] != '\0')
		i++;
	if (i != 1)
		return (0);
	if (s[0] == '+')
		return (1);
	if (s[0] == '-')
		return (2);
	if (s[0] == '*')
		return (3);
	if (s[0] == '/')
		return (4);
	if (s[0] == '%')
		return (5);
	return (0);
}

int		calc(int a, int b, int (*f) (int, int), int arg)
{
	if (arg == 5 && b == 0)
	{
		write(1, "Stop : modulo by zero\n", 22);
		return (0);
	}
	if (arg == 4 && b == 0)
	{
		write(1, "Stop : division by zero\n", 24);
		return (0);
	}
	ft_putnbr(f(a, b));
	write(1, "\n", 1);
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 13:35:13 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/13 20:56:59 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "header.h"

int		main(int argc, char **argv)
{
	int		first;
	int		second;
	int		arg;
	int		res;
	int		(*uk[5]) (int f, int s);

	uk[0] = pluss;
	uk[1] = minuss;
	uk[2] = multipll;
	uk[3] = dividd;
	uk[4] = modd;
	if (argc != 4)
		return (0);
	first = ft_atoi(argv[1]);
	second = ft_atoi(argv[3]);
	arg = is_arg_valid(argv[2]);
	if (arg == 0)
	{
		write(1, "0\n", 2);
		return (0);
	}
	res = calc(first, second, uk[arg - 1], arg);
	return (res);
}

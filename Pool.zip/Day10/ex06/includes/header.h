/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   header.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 17:33:28 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/12 17:49:13 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef __HEADER_H
# define __HEADER_H
# include <unistd.h>

int		is_arg_valid(char *s);
int		pluss(int a, int b);
int		minuss(int a, int b);
int		multipll(int a, int b);
int		dividd(int a, int b);
int		modd(int a, int b);
int		calc(int a, int b, int(*f)(int, int), int arg);
int		ft_atoi(char *str);
void	ft_putnbr(int nb);
void	ft_putchar(char c);
#endif

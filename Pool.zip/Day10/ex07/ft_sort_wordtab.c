/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_wordtab.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/12 19:19:17 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/12 20:14:06 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strcmp(char *s1, char *s2)
{
	int i;

	i = 0;
	while (s1[i])
		if (s1[i] != s2[i])
			return (s2[i] - s1[i]);
		else
			i++;
	return (0);
}

void	ft_sort_wordtab(char **tab)
{
	int		i;
	char	*swap;

	i = 1;
	while (tab[i] != 0)
	{
		if (ft_strcmp(tab[i - 1], tab[i]) < 0)
		{
			swap = tab[i - 1];
			tab[i - 1] = tab[i];
			tab[i] = swap;
			i = 1;
		}
		else
			i++;
	}
}

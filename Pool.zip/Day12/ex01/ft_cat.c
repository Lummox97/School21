/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   display_file.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/14 06:20:50 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/14 23:32:54 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

int		direct_writing(void)
{
	char	buf;

	while (read(0, &buf, 1))
		write(1, &buf, 1);
	return (0);
}

int		aarrggcc(int argc)
{
	if (argc == 1)
	{
		direct_writing();
		return (1);
	}
	return (0);
}

int		error_print(char *arg, char *arc)
{
	extern	const	char	*sys_errlist[];
	int						i;

	i = 0;
	while (*arg)
		write(1, arg++, 1);
	write(1, ": ", 2);
	while (*arc)
		write(1, arc++, 1);
	write(1, ": ", 2);
	while (sys_errlist[errno][i] != '\0')
		write(2, &sys_errlist[errno][i++], 1);
	write(2, "\n", 1);
	return (1);
}

int		main(int argc, char **argv)
{
	int		fd;
	int		ret;
	char	buf[30000];
	int		i;
	int		flag;

	i = 1;
	flag = 0;
	if (aarrggcc(argc))
		return (0);
	while (i < argc)
	{
		fd = open(argv[i++], O_RDONLY);
		if (errno)
			flag = error_print(argv[0], argv[i - 1]);
		ret = read(fd, buf, 30000);
		if (errno && !flag)
			error_print(argv[0], argv[i - 1]);
		while (ret > 0)
		{
			write(1, buf, ret);
			ret = read(fd, buf, 32768);
		}
		close(fd);
	}
}

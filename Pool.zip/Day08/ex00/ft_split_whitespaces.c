/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split_whitespaces.c                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/06 23:04:43 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/09 16:25:07 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		words_count(char *str)
{
	int i;

	i = 0;
	if (str[0] != ' ' && str[0] != '\n' && str[0] != '\t' && str[0] != '\0')
		i++;
	while (*str != '\0')
	{
		if ((*str == ' ' || *str == '\n' || *str == '\t') && *(str + 1) != ' '
			&& *(str + 1) != '\n' && *(str + 1) != '\t' && *(str + 1) != '\0')
			i++;
		str++;
	}
	return (i);
}

int		one_word_count(char *str)
{
	int i;

	i = 0;
	while (str[i] != ' ' && str[i] != '\t' && str[i] != '\n' && str[i] != '\0')
		i++;
	return (i);
}

char	**ft_split_whitespaces(char *str)
{
	char	**words;
	char	*copy;
	int		i;
	int		j;

	copy = str;
	words = malloc(sizeof(char *) * words_count(copy) + 1);
	j = 0;
	while (*copy != '\0' && j < words_count(str))
	{
		while (*copy == ' ' || *copy == '\t' || *copy == '\n')
			copy++;
		words[j] = malloc(sizeof(char) * (one_word_count(copy) + 1));
		i = 0;
		while (copy[i] != ' ' && copy[i] != '\n'
				&& copy[i] != '\t' && copy[i] != '\0')
		{
			words[j][i] = copy[i];
			i++;
		}
		copy += i;
		words[j++][i] = '\0';
	}
	words[j] = 0;
	return (words);
}

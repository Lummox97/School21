/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/01 21:06:52 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/02 20:24:16 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_iterative_power(int nb, int power)
{
	int i;
	int powered;

	i = 0;
	powered = 1;
	if (power < 0)
		return (0);
	while (i < power)
	{
		i++;
		powered *= nb;
	}
	return (powered);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_eight_queens_puzzle.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/02 21:39:18 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/02 23:44:08 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
int my_recursive_function(int *board, int depth)
{
	int i;

	while (1)
	{
		i = 0;
		while (i < depth)
		{
			if ((board[depth] == board[i]) || (board[depth] - board[i] == depth - i) || (board[depth] - board[i] == -1 * (depth - i)))
			{
				board[depth]++;
				i = 0;
			}
			if (board[depth] == 8)
			{
				board[depth] = 0;
				i = 0;
			}
			i++;
			if ((depth == 7) && (i == 7))
				return (0);
		}
		if (my_recursive_function(board, depth + 1) == 1)
			return (1);
		else
			board[depth]++;
	}
}
int		ft_eight_queens_puzzle(void)
{
	int board[8];
	int i;

	i = 0;
	while (i++ < 8)
		board[i-1] = 0;
	i = 0;
//	while (my_recurcive_function(board, 0))
//		i++;
	if (my_recursive_function(board, 0) == 1)
		while (i++ < 8)
			printf("%i", board[i-1]);
	return (i);
}

int main(void)
{
	ft_eight_queens_puzzle();
}

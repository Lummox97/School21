/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort_params.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/05 20:34:19 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/06 23:36:34 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	swap(char **argv, int a, int b)
{
	char *buf;

	buf = argv[a];
	argv[a] = argv[b];
	argv[b] = buf;
}

int		ft_strcmp(char *str1, char *str2)
{
	int				i;
	unsigned char	c1;
	unsigned char	c2;

	i = 0;
	while (str1[i] != '\0' && str2[i] != '\0')
	{
		c1 = (unsigned char)str1[i];
		c2 = (unsigned char)str2[i];
		if (c1 != c2)
			return (c1 - c2);
		else
			i++;
	}
	if (str2[i] == '\0')
		return (1);
	return (0);
}

int		main(int argc, char **argv)
{
	int i;
	int j;

	j = 1;
	while (j < argc - 1)
	{
		if (ft_strcmp(argv[j], argv[j + 1]) > 0)
		{
			swap(argv, j, j + 1);
			j = 1;
		}
		else
			j++;
	}
	i = 1;
	while (i < argc)
	{
		j = 0;
		while (argv[i][j] != '\0')
			ft_putchar(argv[i][j++]);
		ft_putchar('\n');
		i++;
	}
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_concat_params.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/06 21:18:51 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 03:49:35 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_concat_params(int argc, char **argv)
{
	int		i;
	int		j;
	int		k;
	char	*str;

	i = 0;
	j = 1;
	while (j < argc)
	{
		k = 0;
		while (argv[j][k] != '\0')
		{
			k++;
			i++;
		}
		j++;
	}
	str = malloc(i + argc - 1);
	j = 1;
	i = 0;
	while (j< argc)
	{
		k = 0;
		while(argv[j][k] != '\0')
		{
			str[i] = argv[j][k];
			k++;
			i++;
		}
		str[i] = '\n';
		i++;
		j++;
	}
	return (str);
}

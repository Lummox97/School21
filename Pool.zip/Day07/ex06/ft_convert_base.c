/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_base.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/07 21:15:41 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/07 23:34:40 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int		ft_strlen(char *str)
{
	int i;

	i = 0;
	while (str[i] != '\0')
		i++;
	return (i);
}

int		rec_base(int basef, char *nrb, char *base_from)
{
	int i;

	i = 0;
	if (*nrb == '\0')
		return (0);
	while (base_from[i] != '\0')
	{
		if (*nrb == base_from[i])
			return (rec_base(basef, nrb + 1, base_from) * basef + i);
		i++;
	}
}

char 	*ft_putnbr_base(int nbr, char *base, int baset)
{
	int		i;
	int		copy;
	char	*str;

	i = 0;
	copy = nbr;
	while (copy > 0)
	{
		i++;
		copy = copy / baset;
	}
	str = malloc(sizeof(char) * i);


char	*ft_convert_base(char *nbr, char *base_from, char *base_to)
{
	int num;
	int basef;
	int baset;
	int dec_form;

	num = ft_strlen(nbr);
	basef = ft_strlen(base_from);
	baset = ft_strlen(base_to);
	num--;
	dec_form = rec_base(basef, nbr, base_from);


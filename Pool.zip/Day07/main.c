/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/08 15:27:47 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 17:07:01 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	**ft_split_whitespaces(char *str);

void	ft_putstr(char *str);

void	ft_print_words_tables(char **tab);

int		main(void)
{
	char str1[] = " ", str2[] = "";
	ft_print_words_tables(ft_split_whitespaces(str1));
	ft_print_words_tables(ft_split_whitespaces(str2));
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/06 16:44:42 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 03:44:23 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_strdup(char *src)
{
	int		i;
	int		j;
	char	*out;

	i = 0;
	while (src[i] != '\0')
		i++;
	out = malloc(i + 1);
	if (out == NULL)
		return (0);
	j = 0;
	while (j <= i)
	{
		out[j] = src[j];
		j++;
	}
	return (out);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/06 18:16:19 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 03:47:00 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		*ft_range(int min, int max)
{
	int *arr;
	int i;

	if (max <= min)
		return (NULL);
	arr = malloc((max - min) * sizeof(int));
	i = 0;
	while (i < max - min)
	{
		arr[i] = i + min;
		i++;
	}
	return (arr);
}

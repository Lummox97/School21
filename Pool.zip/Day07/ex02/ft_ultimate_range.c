/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/06 18:57:44 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/08 03:47:36 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ft_ultimate_range(int **range, int min, int max)
{
	int i;
	int *a;

	if (max <= min)
	{
		*range = NULL;
		return (0);
	}
	a = malloc((max - min) * sizeof(int));
	if (a == NULL)
		return (NULL);
	i = 0;
	while (i < max - min)
	{
		a[i] = min + i;
		i++;
	}
	*range = a;
	return (i);
}

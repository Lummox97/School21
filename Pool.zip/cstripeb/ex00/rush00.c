/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/03 22:48:05 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/16 21:35:56 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);
int		ft_atoi(char *str);
void	rush1(int x, int y);
void	rush2(int x, int y);
void	rush3(int x, int y);
void	rush4(int x, int y);
void	rush0(int x, int y);

void	rush(int ru, int x, int y)
{
	if (ru == 0)
		rush0(x, y);
	if (ru == 1)
		rush1(x, y);
	if (ru == 2)
		rush2(x, y);
	if (ru == 3)
		rush3(x, y);
	if (ru == 4)
		rush4(x, y);
}

void	rush0(int x, int y)
{
	int i;
	int j;

	i = 1;
	while (i <= y)
	{
		j = 1;
		while (j++ <= x)
			if (i == 1)
				if ((j - 1 == 1) || (j - 1 == x))
					ft_putchar('o');
				else
					ft_putchar('-');
			else if (i == y)
				if ((j - 1 == x) || (j - 1 == 1))
					ft_putchar('o');
				else
					ft_putchar('-');
			else if ((j - 1 == x) || (j - 1 == 1))
				ft_putchar('|');
			else
				ft_putchar(' ');
		ft_putchar('\n');
		i++;
	}
}

int		main(int argc, char **argv)
{
	rush(ft_atoi(argv[1]), ft_atoi(argv[2]), ft_atoi(argv[3]));
}

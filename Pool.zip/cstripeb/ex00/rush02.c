/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   Rush02.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dtilda <marvin@42.fr>                      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/02 19:05:30 by dtilda            #+#    #+#             */
/*   Updated: 2019/03/16 21:35:37 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	rush2(int x, int y)
{
	int i;
	int j;

	i = 1;
	while (i <= y)
	{
		j = 1;
		while (j++ <= x)
			if (i == 1)
				if ((j - 1 == 1) || (j - 1 == x))
					ft_putchar('A');
				else
					ft_putchar('B');
			else if (i == y)
				if ((j - 1 == x) || (j - 1 == 1))
					ft_putchar('C');
				else
					ft_putchar('B');
			else if ((j - 1 == x) || (j - 1 == 1))
				ft_putchar('B');
			else
				ft_putchar(' ');
		ft_putchar('\n');
		i++;
	}
}

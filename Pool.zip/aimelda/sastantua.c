/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sastantua.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aimelda <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/03/03 12:51:28 by aimelda           #+#    #+#             */
/*   Updated: 2019/03/04 11:58:21 by dtilda           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void ft_putchar(char c)
{
	write(1, &c, 1);
}

int		tab_def(int x)
{
	int		sum;

	sum = -2;
	while (x > 0)
	{
		sum += (x / 2) + 2 + x + 1;
		x -= 1;
	}
	return (sum);
}

void	pp(int k, char ch)
{
	while (k > 0)
	{
		ft_putchar(ch);
		k--;
	}
}

void	put_star(int k, int size, int flag, int heigh)
{
	if (size % 2 == 0)
		size -= 1;
	if (flag == 1 && size >= heigh)
	{
		pp(k - (size / 2 + 1), '*');
		if (size / 2 + 1 == heigh && size > 3)
		{
			pp(size - 2, '|');
			ft_putchar('$');
			ft_putchar('|');
		}
		else
			pp(size, '|');
		pp(k - (size / 2 + 1), '*');
	}
	else
		pp(k * 2 - 1, '*');
}

void	piramida(int *tab, int *star, int i, int flag)
{
	int		heigh;
	int		k;

	heigh = i + 2;
	while (heigh > 0)
	{
		k = *tab;
		pp(k, ' ');
		ft_putchar('/');
		put_star(*star, i, flag, heigh);
		ft_putchar('\\');
		ft_putchar('\n');
		*tab -= 1;
		*star += 1;
		heigh--;
	}
}

void	sastantua(int size)
{
	int		tab;
	int		i;
	int		star;

	tab = tab_def(size);
	i = 0;
	star = 1;
	while (i < size)
	{
		i++;
		if (i < size)
			piramida(&tab, &star, i, 0);
		else
			piramida(&tab, &star, i, 1);
		tab -= (i + 1) / 2 + 1;
		star += (i + 1) / 2 + 1;
	}
}

int		main(void)
{
	sastantua(1);
	sastantua(2);
	sastantua(3);
	sastantua(4);
	sastantua(5);
	sastantua(6);
	sastantua(7);
}
